#Analiza sytuacji na rynku pracy w POlsce w roku 2010

#Instalacja pakietu survey
install.packages('survey')

#Wczytywanie pakietu survey
library('survey')

#Sprawdzamy liczbę obserwacji
table (bkl_2010_2014$edycja) 

#Wybieramy rok 2010
rok_2010 <- subset(x=bkl_2010_2014,edycja==2010)

#Obliczamy sumę wag
sum(rok_2010$waga_pop)
summary(rok_2010$waga_pop)
summary(1/rok_2010$waga_pop)

#Hstogram wagi
hist(rok_2010$waga_pop)


##poznajemy pakiet survey
schemat_2010 <-svydesign(
  ##identyfikator "wiązek"
  ids = ~sGUS,
  ##identyfikator warstw
  strata = ~kodpod + wojew + m1_plec + wiek_4k,
  ##wagi (d_i)
  weights = ~waga_pop,
  ##zbiór danych
  data = rok_2010
)

#Obliczamy udział osób bezrobotnych w Polsce w 2010 roku
options(survey.lonely.psu='adjust')
svytotal(x = ~BAEL_bezro,
         design = schemat_2010)

#Obliczamy błąd standardowy szacunku
101167/2108776 #Przeciętnie mylimy się o ok. 4,8%


#Liczymy udział osób bezrobotnych w populacji
svymean(x = ~BAEL_bezro + GUS_bezro, #z wykorzystanie BAEL oraz danych GUS       
        design = schemat_2010) #Stopa bezrobocia w PL w 2010r - 8,25%, Przeciętnie mylimy się o 2,5%.. GUS - brak danych

#Szacujemy udział osób aktywnych zawodowo według województw
svyby(
  formula = ~BAEL_aktyw,
  by = ~wojew,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)

#Liczymy przedział ufności

w1 <- svyby(
  formula = ~BAEL_aktyw,
  by = ~wojew,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'ci'
)

w1



#Z prawdopodobieństwem 95% odsetek pracujących na pełen wymiar czau w Wawie wynosi od ci_l do ci_u dla poszczególnych wojew


#Obliczamy jaki jest udział osób aktywnych zawodowo  ze względu na województwo i płeć
svyby(
  formula = ~BAEL_aktyw,
  by = ~wojew + m1_plec,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)


#Szacujemy średnie zarobki, na.rm ->wyrzucenie pustych danych,

svymean(x = ~m7_zarob,
        design = schemat_2010,
        na.rm = TRUE)



#Szacujemy udział osób pracujących na pełen etat według województw
svyby(
  formula = ~m3_1_pel,
  by = ~wojew,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
  
)
#Gdzue najwięcej? Gdzie najmiej?

#Szacujemy udział osób pracujących na pełen etat według wieku
svyby(
  formula = ~m3_1_pel,
  by = ~wiek_4k,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv' 
)
  #Gdzue najwięcej? Gdzie najmiej?
  



#Obliczamy jaki jest udział osób pracujących ze względu na wiek
svyby(
  formula = ~BAEL_praca,
  by = ~wiek_4k,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)


#Szacujemy udział osób bezrobotnych według województw
svyby(
  formula = ~BAEL_bezro,
  by = ~wojew,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv' 
) 
  #Gdzue najwięcej? Gdzie najmiej?
  
#Szacujemy udział bezrobotnych według miejsca zamieszkania
svyby(
  formula = ~BAEL_bezro,
  by = ~miejsce,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv' 
)

#Szacujemy udział osób bezrobotnych według poziomu wykształcenia 
svyby(
  formula = ~BAEL_bezro,
  by = ~wykszt_nieuczy_4k,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)

#Szacujemy udział osób pracujących "na czarno" w ostatnich 12 miesiącach według województw 
svyby(
  formula =~n0,
  by = ~wojew,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)

#Szacujemy odsetek liczby bezrobotnych osób, który ma dziecko na utrzymaniu
svyby(
  formula = ~BAEL_bezro,
  by = ~m5_dzieci,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)

#Obliczamy odsetek liczby bezrobotnych osób których partner/partnerka również jest bezrobotna/y
svyby(
  formula = ~BAEL_bezro,
  by = ~m4_3_4,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)
  
##################Kody do danych w WORD######################
  
#Obliczamy jaki jest udział osób pracujących ze względu na wiek
svyby(
  formula = ~BAEL_praca,
  by = ~wiek_4k,
  design = schemat_2010,
  FUN = svymean,
  vartype = 'cv'
)  

#Szacujemy udział osób bezrobotnych według poziomu wykształcenia 
  svyby(
    formula = ~BAEL_bezro,
    by = ~wykszt_nieuczy_4k,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )

#Bezrobotni w podziale na płeć  
  svyby(
    formula = ~BAEL_bezro,
    by = ~m1_plec,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )
 
  #Pełen wymiar pracy w podziale na płeć 
  svyby(
    formula = ~m3_1_pel,
    by = ~m1_plec,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv' 
  )
  
  #Etap edukacji w momencie podejmowania pierwszej pracy według płci
  svyby(
    formula = ~m3_1_2,
    by = ~m1_plec,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv' 
  )
  

  #Udział bezrobotnych według województw
  
  svyby(
    formula = ~BAEL_bezro,
    by = ~wojew,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv' 
  ) 
  
  #Szacujemy odsetek liczby bezrobotnych osób, który ma dziecko na utrzymaniu
  svyby(
    formula = ~BAEL_bezro,
    by = ~m5_dzieci,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )

  #Obliczamy odsetek liczby bezrobotnych osób których partner/partnerka również jest bezrobotna/y
  svyby(
    formula = ~BAEL_bezro,
    by = ~m4_3_4,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Osoby pracujące według płci oraz poziomu wykształcenia
  svyby(
    formula = ~BAEL_praca,
    by = ~m1_plec + wykszt_nieuczy_4k,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Przeciętne miesięczne zarobki netto w podziale na wiek
  svyby(
    formula = ~m7_zarob,
    by = ~wiek_4k,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Poziom bezrobocia w podziale na wiek i płeć
  svyby(
    formula = ~BAEL_bezro,
    by = ~wiek_4k + m1_plec,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Poziom wynagrodzenia kobiet i mężczyzn według województw
  svyby(
    formula = ~m7_zarob,
    by = ~m1_plec + wojew,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Etap edukacji w momencie podejmowania pierwszej pracy według płci???
  svyby(
    formula = ~m3_1_2,
    by = ~wojew,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Staż pracy w latach według płci ???
  svyby(
    formula = ~m3_1_staz,
    by = ~m1_plec,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Płeć a zgodność pracy z wykształceniem ???
  svyby(
    formula = ~m3_1_5,
    by = ~m1_plec,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Przeciętne zarobki netto według województw
  svyby(
    formula = ~m7_zarob,
    by = ~wojew,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Udział osób zamieszkałych w miastach/na wsi w strukturze bezrobotnych (zmienna 11 i bezrobocie)
  svyby(
    formula = ~BAEL_bezro,
    by = ~wies,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Praca na pełen etat, a województwo
  svyby(
    formula = ~m3_1_pel,
    by = ~wojew,
    design = schemat_2010,
    na.rm = TRUE,
    FUN = svymean,
    vartype = 'cv'
  )
  #Moment rozpoczęcia pracy w podziale na województwa
  svyby(
    formula = ~m3_1_2,
    by = ~wojew,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )
  
  #Osoby bezrobotne według wieku
  svyby(
    formula = ~BAEL_bezro,
    by = ~wiek_4k,
    design = schemat_2010,
    FUN = svymean,
    vartype = 'cv'
  )