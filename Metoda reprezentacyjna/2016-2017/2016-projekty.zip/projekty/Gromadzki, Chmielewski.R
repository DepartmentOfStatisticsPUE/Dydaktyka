
library(survey)
rok_2014 <- subset(
  x = bkl_2010_2014,
  edycja == 2014
)

sum(rok_2014$waga_pop)
summary(rok_2014$waga_pop)
summary(1/rok_2014$waga_pop)

schemat_2014 <- svydesign(
  ids = ~sGUS,
  strata = ~ kodpod + region8 + wykszt_nieuczy_14k,
  weights = ~ waga_pop,
  data = rok_2014
)
schemat_2014

options(survey.lonely.psu = 'adjust')

AllTotal <- svytotal(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE)

AllTotalRegion <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svytotal, na.rm=TRUE)

AllMean <- svymean(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE)

AllMeanRegion <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svymean, na.rm=TRUE)

## z cv ##
AllTotalCV <- svytotal(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE, vartype = 'cv')
                       
AllTotalRegionCV <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svytotal, na.rm=TRUE, vartype = 'cv')

AllMeanCV <- svymean(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE, vartype = 'cv')

AllMeanRegionCV <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svymean, na.rm=TRUE, vartype = 'cv')

## z przedzia�em ufno�ci##
AllTotalCi <- svytotal(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE, vartype = 'ci')
                       
AllTotalRegionCI <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svytotal, na.rm=TRUE, vartype = 'ci')
                       
AllMeanCI <- svymean(x = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, design = schemat_2014, na.rm=TRUE, vartype = 'ci')
                       
AllMeanRegionCI <- svyby(formula = ~m11_internet + m11_1 + m11_2 + m11_3 + m11_4, by = ~region8, design = schemat_2014, FUN = svymean, na.rm=TRUE, vartype = 'ci')
 
WyksztTotal <- svytotal(x = ~wykszt_nieuczy_14k, design = schemat_2014)                

svyby(formula = ~wykszt, by = ~region8 + wykszt_nieuczy_14k, design = schemat_2014, FUN = svytotal)