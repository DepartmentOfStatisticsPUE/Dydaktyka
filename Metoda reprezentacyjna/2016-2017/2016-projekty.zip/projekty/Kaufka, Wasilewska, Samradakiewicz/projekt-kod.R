library(survey) ## funkcja do wczytania pakietu
load("C:/Users/Ewa/Downloads/bkl_2010_2014.RData")

##
table(bkl_2010_2014$edycja)

table(bkl_2010_2014$GUS_bezro)

###deklaracja zmiennej rok 2014
rok_2014 <- subset(
  x = bkl_2010_2014,
  edycja == 2014, BAEL_aktyw
)

## deklaracja schematu
schemat_2014 <- svydesign(
  ids = ~sGUS,
  strata = ~kodpod + miejsce +
    m1_plec + wiek_4k,
  weights = ~waga_pop,
  data = rok_2014
)
schemat_2014

##ilosc wierszy w schemacie - wielkosc badanej populacji
nrow(schemat_2014)


##ile osob na pelnym etacie, ile bezrobotnych
svymean(x=~m3_1_pel + ~BAEL_bezro, design=schemat_2014)
w2 <-svymean(x=~BAEL_bezro + GUS_bezro + m3_1_pel, design=schemat_2014)
w2
cv(w2)*100

##ilosc respondentow z poszczegolnych wojewodztw
svyby(
  formula = ~BAEL_bezro,
  by = ~ wojew,
  design = schemat_2014,
  FUN =unwtd.count,
  vartype = 'cv'
)

##ilosc respondentow wg wyksztalcenia
countwykszt <- svyby(
  formula = ~BAEL_bezro,
  by = ~ wykszt_5k,
  design = schemat_2014,
  FUN =unwtd.count
)
countwykszt

##piechart populacji wg wyksztalcenia
wartosci <-c(2992, 5149, 2210, 4073, 3250) 
c
etykiety <-c("gimn. i pon.", " srednie og�lnokszt.", "zasadn. zaw.", "policealne, srednie zawodowe","wyzsze")
etykiety
pie (wartosci, labels=etykiety)

##ilosc respondentow wg zgodnosci pracy z wyksztalceniem
pracawykszt <- svyby(
  formula = ~wojew,
  by = ~m3_1_5,
  design = schemat_2014,
  FUN =unwtd.count,
  vartype = 'cv'
)

barplot (pracawykszt, col=c("darkblue"), names.arg=c("zdecydowanie nie", "raczej nie", "raczej tak", "zdecydowanie tak"))

##ile osob srednio jest aktywnych zawodowo wg wyksztalcenia + blad szacunkowy
srwgwyk <-svyby(
  formula = ~BAEL_aktyw,
  by = ~ wykszt_5k,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'cv'
)

barplot(srwgwyk, col = c("darkblue"), names.arg = c("gimnazjalne", "zas.zawodowe","ogolno","�r.zawodowe","wy�sze"))

##pelny etat wg wyksztalcenia + blad szacunkowy
svyby(
  formula = ~m3_1_pel,
  by = ~ wykszt_5k,
  design = schemat_2014,
  FUN = unwtd.count,
  vartype = 'cv'
)

a0 <-c(2272,2259,1204,1422,697)
a0

barplot(a0, col = c("darkblue"), names.arg = c("gimnazjalne", "zas.zawodowe","ogolno","�r.zawodowe","wy�sze"))

a1 <-c(720,2890,1006,2651,2553)
a1

barplot(a1, col = c("darkblue"), names.arg = c("gimnazjalne", "zas.zawodowe","ogolno","�r.zawodowe","wy�sze"))


#przedzial ufnosci dla pelnego etatu wg wyksztalcenia
w3 <- svyby(formula = ~m3_1_pel,
            by=~wykszt_5k,
            design = schemat_2014,
            FUN=svymean,
            vartype = 'ci'
)
w3


##ilosc bezrobotnych po wojewodztwach 
svyby(
  formula = ~m3_1_5,
  by = ~ wykszt_5k,
  design = schemat_2014,
  FUN = svymean,
  na.rm = TRUE,
  vartype = 'cv'
)


##zarobki wg poziomu wyksztalcenia i zgodnosci pracy z wyksztalceniem
zarwgwykszt <- svyby(
  formula = ~m7_zarob,
  by = ~ m3_1_5 + wykszt_5k,
  design = schemat_2014,
  FUN = svymean,
  na.rm=TRUE,
  vartype = 'cv'
)
barplot(zarwgwykszt, main = "Srednie zarobki netto wedlug wyksztalcenia i zgodnosci pracy z wyksztalceniem", names.arg = c("gimnazjalne", "zas. zawodowe", "og�lnoksztalcace", "sr. zawodowe", "wyzsze"))

##zarobki wg zgodnosci pracy z wyksztalceniem
zarwgzgod <- svyby(
  formula = ~m7_zarob,
  by = ~ m3_1_5,
  design = schemat_2014,
  FUN = svymean,
  na.rm=TRUE,
  vartype = 'cv'
)
barplot(zarwgzgod, main = "Srednie zarobki netto wedlug zgodnosci pracy z wyksztalceniem", names.arg = c("zdecydowanie nie", "raczej nie", "raczej tak", "zdecydowanie tak"))

##srednie zarobki wg wyksztalcenia
zarobkiwykszt <- svyby(
  formula = ~m7_zarob,
  by = ~ wykszt_5k,
  design = schemat_2014,
  FUN = svymean, na.rm = TRUE,
  vartype = 'cv'
)



barplot(zarobkiwykszt, main = "srednie zarobki netto wedlug wyksztalcenia", names.arg = c("gimnazjalne", "zas. zawodowe", "og�lnoksztalcace", "sr. zawodowe", "wyzsze"))

##zatrudnieni na pelen etat wg plci i wyksztalcenia
zatrudplecwykszt <- svyby(formula = ~m3_1_pel,
      by=~m1_plec + wykszt_5k,
      design = schemat_2014,
      FUN=svymean,
      vartype = 'cv'
)
barplot(zatrudplecwykszt, main = "Zatrudnieni na pelen etat wedlug plci i wyksztalcenia", names.arg = c("gimnazjalne", "zas. zawodowe", "og�lnoksztalcace", "sr. zawodowe", "wyzsze"))

##bezrobotni wg plci i wyksztalcenia
bezroplecwyksz <- svyby(formula = ~GUS_bezro,
      by=~m1_plec + wykszt_5k,
      design = schemat_2014,
      FUN=svymean,
      vartype = 'cv'
)
barplot(bezroplecwyksz, main = "Bezrobotni wedlug plci i wyksztalcenia", names.arg = c("gimnazjalne", "zas. zawodowe", "og�lnoksztalcace", "sr. zawodowe", "wyzsze"))

##bezrobotni wg wyksztalcenia
svyby(formula = ~GUS_bezro,
      by=~wykszt_5k,
      design = schemat_2014,
      FUN=svymean,
      vartype = 'cv'
)
