library(survey)
load("C:/Users/NikoSobo/Desktop/bkl_2010_2014.RData")
rok_2014 <- subset(
  x = bkl_2010_2014,
  edycja == 2014
)

sum(rok_2014$waga_pop)
summary(rok_2014$waga_pop)

schemat_2014 <- svydesign(
  ids = ~sGUS,
  strata = ~ kodpod + m1_plec + BAEL_sytzaw,
  weights = ~ waga_pop,
  data = rok_2014
)

schemat_2014

options(survey.lonely.psu = 'adjust')


suma <- svytotal(x = ~m3_1_pel + m3_2_niep+m3_3_prze+m3_4_bezr + m3_5_emre+m3_6_uczy+m3_7_dom, design = schemat_2014, na.rm=TRUE)




plec <- svyby(formula = ~m3_1_pel + m3_2_niep+m3_3_prze+m3_4_bezr + m3_5_emre+m3_6_uczy+m3_7_dom, by= ~m1_plec, design = schemat_2014, FUN=svytotal,na.rm=TRUE)
plec
pleccv <- svyby(formula = ~m3_1_pel + m3_2_niep+m3_3_prze+m3_4_bezr + m3_5_emre+m3_6_uczy+m3_7_dom, by= ~m1_plec, design = schemat_2014, FUN=svytotal,na.rm=TRUE, vartype='cv')
pleccv
srednio <- svymean(x = ~m3_1_pel + m3_2_niep+m3_3_prze+m3_4_bezr + m3_5_emre+m3_6_uczy+m3_7_dom, design = schemat_2014, na.rm=TRUE)
srednio
stazpracy <- svyby(formula = ~m3_1_staz, by= ~m1_plec, design = schemat_2014, FUN=svytotal,na.rm=TRUE)
stazpracy
przed.ufn1 <- svyby(
  formula = ~m3_1_pel,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn1

przed.ufn2 <- svyby(
  formula = ~m3_2_niep,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn2

przed.ufn3 <- svyby(
  formula = ~m3_3_prze,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn3

przed.ufn4 <- svyby(
  formula = ~m3_4_bezr,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn4

przed.ufn5 <- svyby(
  formula = ~m3_5_emre,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn5

przed.ufn6 <- svyby(
  formula = ~m3_6_uczy,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn6

przed.ufn7 <- svyby(
  formula = ~m3_7_dom,
  by = ~m1_plec,
  design = schemat_2014,
  FUN = svymean,
  vartype = 'ci'
)
przed.ufn7