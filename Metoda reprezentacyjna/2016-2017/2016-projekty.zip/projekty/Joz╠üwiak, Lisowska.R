install.packages('survey')
install.packages('sampling')
install.packages('laeken')
library('survey')
library('sampling')
library('laeken')
## Obliczenia dla 2014 roku
table(bkl_2010_2014$edycja)
rok_2014 <- subset(
  x = bkl_2010_2014,
  edycja == 2014)
sum(rok_2014$waga_pop)
summary(rok_2014$waga_pop)
summary(1/rok_2014$waga_pop)
hist(rok_2014$waga_pop, 
     main = "Rozk�ad wag w roku 2014",
     ylab = "cz�stotliwo��",
     xlab = "waga",
     col='gray')
hist((1/rok_2014$waga_pop)*100, 
     main = "Prawdopodobie�stwo dostania si� do pr�by w roku 2014",
     ylab = "cz�stotliwo��",
     xlab = "procent",
     col='gray')
schemat_2014 <-svydesign(ids = ~sGUS, 
                         strata = ~kodpod + miejsce + m1_plec + wiek_4k,
                         weights = ~waga_pop,
                         data = rok_2014) 
options(survey.lonely.psu='adjust')
svytotal(x=~m5_dzieci,
         design = schemat_2014)
575609/14101884
svymean(x=~m5_dzieci,
        design = schemat_2014)
0.0054/0.57583
w1 <- svymean(x=~m5_dzieci,
              design = schemat_2014)
cv(w1)
summary(rok_2014$m5_1)
barplot(table(rok_2014$m5_1))
table(rok_2014$m5_1)
svyby (formula = ~m5_1,
       by = ~wojew,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")
svyby (formula = ~m5_1,
       by = ~miejsce,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")
svyby (formula = ~m5_1,
       by = ~m3_1_pel,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")
svyby (formula = ~m5_1,
       by = ~m3_7_dom,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")
svyby (formula = ~m5_1,
       by = ~m4_cywil,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")
svyby (formula = ~m5_1,
       by = ~wykszt_4k,
       design = schemat_2014, 
       FUN = svymean,
       vartype = "cv")


##Obliczenia dla 2010 roku

na.omit=TRUE
table(bkl_2010_2014$edycja)
rok_2010 <- subset(
  x = bkl_2010_2014,
  edycja == 2010)
sum(rok_2010$waga_pop,
    rm.na=TRUE)
summary(rok_2010$waga_pop,
        rm.na=TRUE)
summary(1/rok_2010$waga_pop)
hist(rok_2010$waga_pop, 
     main = "Rozk�ad wag w roku 2010",
     ylab = "cz�stotliwo��",
     xlab = "waga",
     col='blue')
hist((1/rok_2010$waga_pop)*100, 
     main = "Prawdopodobie�stwo dostania si� do pr�by w roku 2010",
     ylab = "cz�stotliwo��",
     xlab = "procent",
     col='blue')
schemat_2010 <-svydesign(ids = ~sGUS, 
                         strata = ~kodpod + miejsce + m1_plec + wiek_4k,
                         weights = ~waga_pop,
                         data = rok_2010) 
options(survey.lonely.psu='adjust')
svytotal(x=~m5_dzieci,
         design = schemat_2010,
         na.rm=TRUE)
655630/16183691
svymean(x=~m5_dzieci,
        design = schemat_2010,
        na.rm=TRUE)
0.0048/0.63381
w2 <- svymean(x=~m5_dzieci,
              design = schemat_2010,
              na.rm=TRUE)
cv(w2)
summary(rok_2010$m5_1) 
barplot(table(rok_2010$m5_1))
table(rok_2010$m5_1)
svyby (formula = ~m5_1,
       by = ~wojew,
       design = schemat_2010, 
       FUN = svymean,
       vartype = "cv",
       na.rm=TRUE)
svyby (formula = ~m5_1,
       by = ~miejsce,
       design = schemat_2010, 
       FUN = svymean,
       vartype = "cv",
       na.rm=TRUE)
svyby (formula = ~m5_1,
       by = ~m3_1_pel,
       design = schemat_2010, 
       FUN = svymean,
       vartype = "cv",
       na.rm=TRUE)
svyby (formula = ~m5_1,
       by = ~m3_7_dom,
       design = schemat_2010, 
       FUN = svymean,
       vartype = "cv",
       na.rm=TRUE)
svyby (formula = ~m5_1,
       by = ~m4_cywil,
       design = schemat_2010, 
       FUN = svymean,
       vartype = 'cv',
       na.rm=TRUE)
svyby (formula = ~m5_1,
       by = ~malz,
       design = schemat_2010, 
       FUN = svymean,
       vartype = 'cv',
       na.rm= TRUE)
svyby (formula = ~m5_1,
       by = ~wykszt_4k,
       design = schemat_2010, 
       FUN = svymean,
       vartype = "cv",
       na.rm=TRUE)


sCyw2010 <- c("odmowa odp."=102,
              "ma��enstwo"=183,
              "zwiazek nieformalny"=93,
              "rozwiedziony/a"=160,
              "wdowiec/a"=212,
              "w separacji"=155,
              "wolny"=13)
sCyw2014 <- c("odmowa odp."=66,
              "ma��enstwo"=171,
              "zwiazek nieformalny"=92,
              "rozwiedziony/a"=148,
              "wdowiec/a"=197,
              "w separacji"=157,
              "wolny"=9)
sCyw <- c("odmowa odp."=102,66,
          "ma��enstwo"=183,171,
          "zwiazek niefor."=93,92,
          "rozwiedziony/a"=160,148,
          "wdowiec/a"=212,197,
          "w separacji"=155,157,
          "wolny"=13,9)

nazwy<- c("grey", "blue")
lata <-c("2010", "2014")

barplot(sCyw, 
        main = "Liczba dzieci na 100 gospodarstw domowych w roku 2010 i 2014",
        ylab = "Liczba dzieci",
        xlab="stan cywilny",
        col = nazwy,
        legend=lata, 
        args.legend=list(x="topright"))

wyksztalcenie <- c(
  "gimnazjalne i nizsze"=126,81,
  "zasadnicze zawodowe"=158,143,
  "srednie"=113,105,
  "wyzsze"=108,103)
barplot(wyksztalcenie, 
        main = "Liczba dzieci na 100 gospodarstw domowych w roku 2010 i 2014",
        ylab = "Liczba dzieci",
        xlab="poziom wyksztalcenia",
        col = nazwy,
        legend=lata, 
        args.legend=list(x="topright"))

sytuacjaZaw <- c(
  "praca na pelen etat"=122,119,
  "zajmuje sie domem"=131,180)
barplot(sytuacjaZaw, 
        main = "Liczba dzieci na 100 gospodarstw domowych w roku 2010 i 2014",
        ylab = "Liczba dzieci",
        xlab="sytuacja zawodowa",
        col = nazwy,
        legend=lata, 
        args.legend=list (x="topright"))

Wmiejsce <- c("wie�"=130,115,
              "m<10tys"=122,119,
              "m10-19tys"=131,113,
              "m20-49tys"=129,111,
              "m50-99tys"=135,120,
              "m100-199tys"=123,122,
              "m200-499tys"=128,104,
              "m>500tys"=111,99,
              "W-wa"=114,76)
barplot(Wmiejsce, 
        main = "Liczba dzieci na 100 gospodarstw domowych w roku 2010 i 2014",
        ylab = "Liczba dzieci",
        xlab="wielkosc miejscowosci",
        col = nazwy,
        legend=lata, 
        args.legend=list (x="bottomright"))













