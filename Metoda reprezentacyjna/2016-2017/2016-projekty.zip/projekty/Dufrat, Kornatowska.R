#Wczytanie pakietu survey
library(survey)
#wyb�r roku 2014:
rok_2014 <- subset(
  x = bkl_2010_2014,
  edycja == 2014
)
#Podgl�d ile w danym roku by�o obserwacji:
table(bkl_2010_2014$edycja)
summary(rok_2014$waga_pop)
#Rozk�ad prawdopodbie�stwa dostania si� do pr�by 2014:
summary(1/rok_2014$waga_pop)
# Schemat 2014
schemat_2014 <- svydesign(
  ids = ~sGUS,
  strata = ~ kodpod + miejsce +
    m1_plec + wiek_4k + wykszt_nieuczy_4k + wojew,
  weights = ~ waga_pop,
  data = rok_2014
)
options(survey.lonely.psu = 'adjust')
#Wykszta�cenie w�r�d pracuj�cych og�em:
wo1 <- svymean(x = ~factor(wykszt_nieuczy_4k),
         design = subset(schemat_2014, BAEL_praca == 1))
##mediana, kwartyle - osoby pracuj�ce og�em
wo1m <- svyquantile(
  x = ~factor(wykszt_nieuczy_4k),
  design = subset(schemat_2014, BAEL_praca == 1),
  na.rm= TRUE,
  quantiles = c(0.25,0.5,0.75)) ##1,3 kwantyl i srodek
#Wykszta�cenie w�r�d bezrobotnych og�em:
wo2 <- svymean(x = ~factor(wykszt_nieuczy_4k),
               design = subset(schemat_2014, BAEL_bezro == 1))
##mediana kwartyle - osoby bezrobotne og�em
wo2m <- svyquantile(
  x = ~factor(wykszt_nieuczy_4k),
  design = subset(schemat_2014, BAEL_bezro == 1),
  na.rm= TRUE,
  quantiles = c(0.25,0.5,0.75)) ##1,3 kwantyl i srodek
#Wykszta�cenie w�r�d pracuj�cych wg wieku
w1 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ wiek_5k,
  design = subset(schemat_2014, BAEL_praca == 1), ## wybieram osoby pracuj�ce
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d pracuj�cych wg p�ci
w2 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ m1_plec,
  design = subset(schemat_2014, BAEL_praca == 1), ## wybieram osoby pracuj�ce
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d pracuj�cych wg wojew�dztwa
w3 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ wojew,
  design = subset(schemat_2014, BAEL_praca == 1), ## wybieram osoby pracuj�ce
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d pracuj�cych wg miejsca zmieszkania
w4 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ miejsce,
  design = subset(schemat_2014, BAEL_praca == 1), ## wybieram osoby pracuj�ce
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d bezrobotnych wg wieku
w5 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ wiek_4k,
  design = subset(schemat_2014, BAEL_bezro == 1), ## wybieram osoby bezrobotne
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d bezrobotnych wg p�ci
w6 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ m1_plec,
  design = subset(schemat_2014, BAEL_bezro == 1), ## wybieram osoby bezrobotne
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d bezrobotnych wg wojew�dztwa
w7 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ wojew,
  design = subset(schemat_2014, BAEL_bezro == 1), ## wybieram osoby bezrobotne
  FUN = svymean,
  vartype = "cv" )
#Wykszta�cenie w�r�d bezrobotnych wg miejsca zmieszkania
w8 <- svyby(
  formula = ~factor(wykszt_nieuczy_4k),
  by = ~ miejsce,
  design = subset(schemat_2014, BAEL_bezro == 1), ## wybieram osoby bezrobotne
  FUN = svymean,
  vartype = "cv" )
#wczytywanie
wo1
wo2
wo1m
wo2m
w1
w2
w3
w4
w5
w6
w7
w8
